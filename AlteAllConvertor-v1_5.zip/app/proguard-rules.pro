# R8 для Compose-приложения: правила приходят вместе с библиотеками.
-keepattributes SourceFile,LineNumberTable

package com.alte.allconvertor

import android.util.Base64
import org.json.JSONObject
import java.io.File
import java.io.FilterOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

class Gh(private val token: String, private val workflow: String) {
    private var owner = ""
    private val repo = "alte-builder"
    private val api = "https://api.github.com"

    private fun open(method: String, url: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 30000; c.readTimeout = 180000
        c.setRequestProperty("Authorization", "Bearer $token")
        c.setRequestProperty("Accept", "application/vnd.github+json")
        return c
    }

    private fun read(c: HttpURLConnection): Pair<Int, String> {
        val code = c.responseCode
        val txt = (if (code < 400) c.inputStream else c.errorStream)?.bufferedReader()?.readText().orEmpty()
        return code to txt
    }

    private fun call(method: String, url: String, body: String? = null): Pair<Int, String> {
        val c = open(method, url)
        if (body != null) { c.doOutput = true; c.outputStream.use { it.write(body.toByteArray()) } }
        return read(c)
    }

    /** PUT файла в репозиторий: base64 кодируется потоком, ZIP целиком в памяти не держится. Возвращает sha. */
    private fun putStream(path: String, sha: String?, src: () -> InputStream): String {
        val c = open("PUT", "$api/repos/$owner/$repo/contents/$path")
        c.doOutput = true
        c.setChunkedStreamingMode(64 * 1024)
        c.outputStream.use { raw ->
            val head = "{\"message\":\"alte\"" + (if (sha != null) ",\"sha\":\"$sha\"" else "") + ",\"content\":\""
            raw.write(head.toByteArray())
            val keepOpen = object : FilterOutputStream(raw) {
                override fun write(b: ByteArray, off: Int, len: Int) { out.write(b, off, len) }
                override fun close() { flush() }
            }
            val enc = java.util.Base64.getEncoder().wrap(keepOpen)
            src().use { it.copyTo(enc, 64 * 1024) }
            enc.close()
            raw.write("\"}".toByteArray())
        }
        val (code, txt) = read(c)
        if (code !in 200..201) error("GitHub $code: ${txt.take(160)}")
        return JSONObject(txt).getJSONObject("content").getString("sha")
    }

    private fun remove(path: String, sha: String) {
        try {
            call("DELETE", "$api/repos/$owner/$repo/contents/$path",
                JSONObject().put("message", "clean").put("sha", sha).toString())
        } catch (_: Exception) { }
    }

    fun setup() {
        val (c, t) = call("GET", "$api/user")
        if (c != 200) error("Неверный токен ($c)")
        owner = JSONObject(t).getString("login")
        if (call("GET", "$api/repos/$owner/$repo").first == 404) {
            val (cc, ct) = call("POST", "$api/user/repos", """{"name":"$repo","private":true,"auto_init":true}""")
            if (cc != 201) error("Не создался репозиторий: ${ct.take(160)}")
            Thread.sleep(3000)
        }
        // workflow синхронизируется при каждом запуске: новая версия ускорения применяется автоматически
        val path = ".github/workflows/build.yml"
        val (wc, wt) = call("GET", "$api/repos/$owner/$repo/contents/$path")
        val bytes = workflow.toByteArray()
        if (wc != 200) {
            putStream(path, null) { bytes.inputStream() }
        } else {
            val j = JSONObject(wt)
            val cur = String(Base64.decode(j.getString("content"), Base64.DEFAULT))
            if (cur.trim() != workflow.trim()) putStream(path, j.getString("sha")) { bytes.inputStream() }
        }
    }

    fun build(zip: () -> InputStream, out: File, step: (Int) -> Unit) {
        val job = UUID.randomUUID().toString().take(8)
        val zipPath = "jobs/$job.zip"
        step(1)
        val zipSha = putStream(zipPath, null, zip)
        try {
            if (Thread.currentThread().isInterrupted) throw InterruptedException()
            var ok = false
            repeat(10) {
                if (!ok) {
                    val r = call("POST", "$api/repos/$owner/$repo/actions/workflows/build.yml/dispatches",
                        """{"ref":"main","inputs":{"job":"$job"}}""")
                    if (r.first == 204) ok = true else Thread.sleep(2000)
                }
            }
            if (!ok) error("Не удалось запустить сборку (нужны права repo + workflow у токена)")
            step(2)
            var runId = 0L
            val t0 = System.currentTimeMillis()
            while (runId == 0L) {
                if (System.currentTimeMillis() - t0 > 40 * 60 * 1000) error("Таймаут сборки")
                Thread.sleep(if (System.currentTimeMillis() - t0 < 90_000) 3000 else 5000)
                val (c, t) = call("GET", "$api/repos/$owner/$repo/actions/runs?event=workflow_dispatch&per_page=10")
                if (c != 200) continue
                val runs = JSONObject(t).getJSONArray("workflow_runs")
                for (i in 0 until runs.length()) {
                    val r = runs.getJSONObject(i)
                    if (r.optString("display_title") == "build $job" && r.getString("status") == "completed") {
                        if (r.getString("conclusion") != "success") error("Сборка упала. Лог: ${r.getString("html_url")}")
                        runId = r.getLong("id")
                    }
                }
            }
            step(3)
            val (_, at) = call("GET", "$api/repos/$owner/$repo/actions/runs/$runId/artifacts")
            val arts = JSONObject(at).getJSONArray("artifacts")
            if (arts.length() == 0) error("APK не найден в результатах сборки")
            val id = arts.getJSONObject(0).getLong("id")
            val conn = URL("$api/repos/$owner/$repo/actions/artifacts/$id/zip").openConnection() as HttpURLConnection
            conn.instanceFollowRedirects = false
            conn.connectTimeout = 30000; conn.readTimeout = 60000
            conn.setRequestProperty("Authorization", "Bearer $token")
            val loc = conn.getHeaderField("Location") ?: error("Нет ссылки на скачивание")
            conn.disconnect()
            val tmp = File(out.path + ".zip")
            try {
                URL(loc).openConnection().apply { connectTimeout = 30000; readTimeout = 120000 }
                    .getInputStream().use { i -> tmp.outputStream().buffered(256 * 1024).use { o -> i.copyTo(o, 256 * 1024) } }
                java.util.zip.ZipFile(tmp).use { z ->
                    val e = z.entries().toList()
                        .filter { !it.isDirectory && it.name.endsWith(".apk") }
                        .sortedBy { if (it.name.contains("unsigned")) 1 else 0 }
                        .firstOrNull() ?: error("APK не найден в архиве")
                    z.getInputStream(e).use { i -> out.outputStream().buffered(256 * 1024).use { o -> i.copyTo(o, 256 * 1024) } }
                }
            } finally {
                tmp.delete()
            }
        } finally {
            remove(zipPath, zipSha) // не копим старые ZIP в репозитории — checkout остаётся быстрым
        }
    }
}

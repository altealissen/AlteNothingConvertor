package com.alte.allconvertor

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.provider.OpenableColumns
import android.text.format.DateFormat
import android.text.format.Formatter
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { NTheme { Home() } }
    }
}

enum class St { Idle, Run, Done, Fail }

fun apkName(ctx: Context, uri: android.net.Uri): String {
    val raw = ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
        ?.use { if (it.moveToFirst()) it.getString(0) else null } ?: "app"
    val base = raw.removeSuffix(".zip").replace(Regex("[^A-Za-z0-9._-]"), "_").take(60).ifEmpty { "app" }
    return base + "_" + SimpleDateFormat("yyyy-MM-dd_HH-mm", Locale.US).format(Date()) + ".apk"
}

@Composable
fun Home() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("alte", 0) }
    var token by remember { mutableStateOf(prefs.getString("t", "") ?: "") }
    var editing by remember { mutableStateOf(token.isEmpty()) }
    var history by remember { mutableStateOf(false) }
    // Состояние живёт в BuildService (foreground) — сборка не прерывается при сворачивании приложения.
    val ui by BuildState.state.collectAsState()

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) BuildService.start(ctx, uri)
    }
    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        pick.launch(arrayOf("*/*"))
    }
    fun startPick() {
        if (token.isEmpty()) { editing = true; return }
        if (Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notif.launch(Manifest.permission.POST_NOTIFICATIONS)
        else pick.launch(arrayOf("*/*"))
    }

    if (history) {
        BackHandler { history = false }
        History(onBack = { history = false })
    } else {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).background(NRed, CircleShape))
                Spacer(Modifier.size(10.dp))
                Mono("Alte All Convertor", Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurface, bold = true)
                Mono("v1.4")
            }
            DotText("ZIP→APK", maxPitch = 9.dp)
            Mono("Собери APK из ZIP прямо на телефоне", size = 11.sp)

            AnimatedVisibility(editing, enter = expandVertically() + fadeIn(), exit = shrinkVertically() + fadeOut()) {
                var tmp by remember { mutableStateOf(token) }
                val cs = MaterialTheme.colorScheme
                NCard(Modifier.fillMaxWidth(), RoundedCornerShape(28.dp)) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Mono("GitHub-токен", color = cs.onSurface, bold = true)
                        Text(
                            "GitHub → Settings → Developer settings → Personal access tokens (classic). Отметь права repo и workflow.",
                            style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant
                        )
                        OutlinedTextField(
                            tmp, { tmp = it }, singleLine = true, label = { Text("ghp_...") },
                            shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = cs.onSurface, unfocusedBorderColor = cs.outline,
                                focusedLabelColor = cs.onSurface, unfocusedLabelColor = cs.onSurfaceVariant,
                                cursorColor = NRed
                            )
                        )
                        NButton(
                            "Сохранить",
                            { token = tmp.trim(); prefs.edit().putString("t", token).apply(); editing = false },
                            Modifier.fillMaxWidth(), primary = true, compact = true
                        )
                    }
                }
            }

            AnimatedContent(
                ui.st, Modifier.weight(1f).fillMaxWidth(), label = "stage",
                transitionSpec = { (fadeIn(tween(300)) + slideInVertically { it / 12 }) togetherWith fadeOut(tween(150)) }
            ) { s ->
                when (s) {
                    St.Idle -> IdleCard(
                        onPick = { startPick() },
                        onHistory = { history = true },
                        onToken = { editing = !editing }
                    )
                    St.Run -> RunCard(ui)
                    St.Done -> DoneCard(ui.apk, onHistory = { history = true })
                    St.Fail -> FailCard(ui.msg)
                }
            }
            Spacer(Modifier.height(4.dp))
        }
    }
}

@Composable
fun IdleCard(onPick: () -> Unit, onHistory: () -> Unit, onToken: () -> Unit) {
    NCard(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Mono("Готов к сборке")
            DotOrb(Modifier.size(200.dp))
            Column(verticalArrangement = Arrangement.spacedBy(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    "Выбери ZIP с Android-проектом", style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center
                )
                NButton("Выбрать ZIP", onPick, Modifier.fillMaxWidth(), primary = true, icon = Icons.Default.Add)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    NButton("История", onHistory, Modifier.weight(1f), compact = true)
                    NButton("Токен", onToken, Modifier.weight(1f), compact = true)
                }
            }
        }
    }
}

@Composable
fun RunCard(ui: UiState) {
    val ctx = LocalContext.current
    val names = listOf("Подготовка", "Загрузка ZIP", "Сборка в облаке", "Скачивание APK")
    val step = ui.step.coerceIn(0, 3)
    NCard(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Mono("Сборка · ${step + 1}/4")
                BuildTimer(ui.startedAt)
            }
            Column(verticalArrangement = Arrangement.spacedBy(18.dp)) {
                names.forEachIndexed { i, name -> StepRow(name, i, step) }
            }
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                DotBar((step + 0.5f) / 4f, running = true)
                Mono("Можно свернуть — пришлю уведомление", size = 11.sp)
                NButton("Отмена", { BuildService.cancel(ctx) }, Modifier.fillMaxWidth(), danger = true, compact = true)
            }
        }
    }
}

@Composable
fun BuildTimer(startedAt: Long) {
    var now by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }
    LaunchedEffect(Unit) { while (true) { now = SystemClock.elapsedRealtime(); delay(1000) } }
    val sec = ((now - startedAt) / 1000).coerceAtLeast(0)
    DotText(String.format(Locale.US, "%02d:%02d", sec / 60, sec % 60), maxPitch = 7.dp)
}

@Composable
fun StepRow(name: String, i: Int, step: Int) {
    val cs = MaterialTheme.colorScheme
    val done = i < step
    val cur = i == step
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        when {
            cur -> PulseDot()
            else -> Canvas(Modifier.size(20.dp)) {
                if (done) drawCircle(cs.onSurface, size.minDimension * 0.42f, center)
                else drawCircle(cs.outline, size.minDimension * 0.38f, center, style = Stroke(width = 2.dp.toPx()))
            }
        }
        Text(
            name, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium,
            fontWeight = if (cur) FontWeight.Bold else FontWeight.Normal,
            color = if (done || cur) cs.onSurface else cs.onSurfaceVariant
        )
        if (done) Mono("OK", size = 11.sp)
        if (cur) Mono("LIVE", color = NRed, size = 11.sp, bold = true)
    }
}

@Composable
fun PulseDot() {
    val inf = rememberInfiniteTransition(label = "sd")
    val pulse by inf.animateFloat(0.15f, 0.5f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "p")
    Canvas(Modifier.size(20.dp)) {
        drawCircle(NRed.copy(alpha = pulse), size.minDimension * 0.5f, center)
        drawCircle(NRed, size.minDimension * 0.27f, center)
    }
}

@Composable
fun DoneCard(apk: SavedApk?, onHistory: () -> Unit) {
    val ctx = LocalContext.current
    NCard(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Mono("Сборка завершена")
                DotText("READY", maxPitch = 12.dp)
            }
            if (apk != null) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(apk.name, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                    Mono(Formatter.formatShortFileSize(ctx, apk.size) + " · " + ApkStore.folderLabel(), size = 11.sp)
                }
            }
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                NButton("Установить", { apk?.let { ApkStore.install(ctx, it) } }, Modifier.fillMaxWidth(), primary = true)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    NButton("История", onHistory, Modifier.weight(1f), compact = true)
                    NButton("Ещё", { BuildState.reset() }, Modifier.weight(1f), compact = true)
                }
            }
        }
    }
}

@Composable
fun FailCard(msg: String) {
    NCard(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Mono("Сборка не удалась", color = NRed, bold = true)
            DotText("FAIL", maxPitch = 12.dp, color = NRed)
            Text(
                msg, Modifier.weight(1f).verticalScroll(rememberScrollState()),
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            NButton("Назад", { BuildState.reset() }, Modifier.fillMaxWidth(), primary = true)
        }
    }
}

@Composable
fun History(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()
    var items by remember { mutableStateOf<List<SavedApk>?>(null) }
    var toDelete by remember { mutableStateOf<SavedApk?>(null) }

    fun reload() { scope.launch { items = withContext(Dispatchers.IO) { ApkStore.list(ctx) } } }
    LaunchedEffect(Unit) { reload() }

    toDelete?.let { a ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            shape = RoundedCornerShape(28.dp),
            containerColor = cs.surfaceContainerHigh,
            title = { Mono("Удалить APK?", color = cs.onSurface, bold = true, size = 14.sp) },
            text = { Text(a.name, color = cs.onSurfaceVariant) },
            confirmButton = {
                TextButton({
                    scope.launch { withContext(Dispatchers.IO) { ApkStore.delete(ctx, a) }; toDelete = null; reload() }
                }) { Mono("Удалить", color = NRed, bold = true) }
            },
            dismissButton = { TextButton({ toDelete = null }) { Mono("Отмена", color = cs.onSurface) } }
        )
    }

    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Spacer(Modifier.height(4.dp))
        IconButton(onBack) { Icon(Icons.Default.ArrowBack, "Назад") }
        DotText("HISTORY", maxPitch = 8.dp)
        Mono(ApkStore.folderLabel(), size = 11.sp)
        val list = items
        when {
            list == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = NRed, strokeWidth = 2.dp)
            }
            list.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    DotText("EMPTY", maxPitch = 8.dp)
                    Mono("Собранные APK появятся здесь", align = TextAlign.Center, size = 11.sp)
                }
            }
            else -> LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                items(list, key = { it.uri.toString() }) { a ->
                    NCard(Modifier.fillMaxWidth(), RoundedCornerShape(24.dp)) {
                        Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(a.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            Mono(
                                DateFormat.format("dd.MM.yyyy HH:mm", a.time).toString() + " · " +
                                    Formatter.formatShortFileSize(ctx, a.size),
                                size = 11.sp
                            )
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                NButton("Установить", { ApkStore.install(ctx, a) }, Modifier.weight(1f), primary = true, compact = true)
                                NButton("Удалить", { toDelete = a }, danger = true, compact = true, icon = Icons.Default.Delete)
                            }
                        }
                    }
                }
            }
        }
    }
}

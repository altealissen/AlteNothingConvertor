package com.alte.allconvertor

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.pow

/** Фирменный красный Nothing — используем только как акцент. */
val NRed = Color(0xFFD71921)

private val DarkScheme = darkColorScheme(
    primary = Color.White, onPrimary = Color.Black,
    secondary = Color(0xFF2A2A2A), onSecondary = Color.White,
    tertiary = NRed, onTertiary = Color.White,
    background = Color.Black, onBackground = Color.White,
    surface = Color.Black, onSurface = Color.White,
    surfaceVariant = Color(0xFF1E1E1E), onSurfaceVariant = Color(0xFF8E8E8E),
    surfaceContainerHigh = Color(0xFF121212),
    outline = Color(0xFF3C3C3C), outlineVariant = Color(0xFF242424),
    error = NRed, onError = Color.White,
    errorContainer = Color(0xFF2A0A0C), onErrorContainer = Color.White
)

private val LightScheme = lightColorScheme(
    primary = Color(0xFF0A0A0A), onPrimary = Color.White,
    secondary = Color(0xFFE2E2E2), onSecondary = Color.Black,
    tertiary = NRed, onTertiary = Color.White,
    background = Color(0xFFF2F2F2), onBackground = Color(0xFF0A0A0A),
    surface = Color(0xFFF2F2F2), onSurface = Color(0xFF0A0A0A),
    surfaceVariant = Color(0xFFE4E4E4), onSurfaceVariant = Color(0xFF6B6B6B),
    surfaceContainerHigh = Color.White,
    outline = Color(0xFFB4B4B4), outlineVariant = Color(0xFFDADADA),
    error = NRed, onError = Color.White,
    errorContainer = Color(0xFFFBE4E5), onErrorContainer = Color(0xFF0A0A0A)
)

/** Статичная палитра (без dynamic color — Nothing OS её не использует, и это быстрее). */
@Composable
fun NTheme(content: @Composable () -> Unit) {
    val cs = if (isSystemInDarkTheme()) DarkScheme else LightScheme
    MaterialTheme(colorScheme = cs) {
        Surface(Modifier.fillMaxSize(), color = cs.background, contentColor = cs.onBackground, content = content)
    }
}

// ───────────────────────── Dot-matrix шрифт 5×7 ─────────────────────────

private fun g(s: String) = s.split(" ")

private val BLANK = g("00000 00000 00000 00000 00000 00000 00000")

private val GLYPHS: Map<Char, List<String>> = mapOf(
    'A' to g("01110 10001 10001 11111 10001 10001 10001"),
    'B' to g("11110 10001 10001 11110 10001 10001 11110"),
    'C' to g("01110 10001 10000 10000 10000 10001 01110"),
    'D' to g("11110 10001 10001 10001 10001 10001 11110"),
    'E' to g("11111 10000 10000 11110 10000 10000 11111"),
    'F' to g("11111 10000 10000 11110 10000 10000 10000"),
    'G' to g("01110 10001 10000 10111 10001 10001 01111"),
    'H' to g("10001 10001 10001 11111 10001 10001 10001"),
    'I' to g("01110 00100 00100 00100 00100 00100 01110"),
    'J' to g("00111 00010 00010 00010 00010 10010 01100"),
    'K' to g("10001 10010 10100 11000 10100 10010 10001"),
    'L' to g("10000 10000 10000 10000 10000 10000 11111"),
    'M' to g("10001 11011 10101 10101 10001 10001 10001"),
    'N' to g("10001 11001 10101 10011 10001 10001 10001"),
    'O' to g("01110 10001 10001 10001 10001 10001 01110"),
    'P' to g("11110 10001 10001 11110 10000 10000 10000"),
    'Q' to g("01110 10001 10001 10001 10101 10010 01101"),
    'R' to g("11110 10001 10001 11110 10100 10010 10001"),
    'S' to g("01111 10000 10000 01110 00001 00001 11110"),
    'T' to g("11111 00100 00100 00100 00100 00100 00100"),
    'U' to g("10001 10001 10001 10001 10001 10001 01110"),
    'V' to g("10001 10001 10001 10001 10001 01010 00100"),
    'W' to g("10001 10001 10001 10101 10101 11011 10001"),
    'X' to g("10001 10001 01010 00100 01010 10001 10001"),
    'Y' to g("10001 10001 01010 00100 00100 00100 00100"),
    'Z' to g("11111 00001 00010 00100 01000 10000 11111"),
    '0' to g("01110 10001 10011 10101 11001 10001 01110"),
    '1' to g("00100 01100 00100 00100 00100 00100 01110"),
    '2' to g("01110 10001 00001 00010 00100 01000 11111"),
    '3' to g("11110 00001 00001 01110 00001 00001 11110"),
    '4' to g("00010 00110 01010 10010 11111 00010 00010"),
    '5' to g("11111 10000 11110 00001 00001 10001 01110"),
    '6' to g("00110 01000 10000 11110 10001 10001 01110"),
    '7' to g("11111 00001 00010 00100 01000 01000 01000"),
    '8' to g("01110 10001 10001 01110 10001 10001 01110"),
    '9' to g("01110 10001 10001 01111 00001 00010 01100"),
    ':' to g("00000 00100 00100 00000 00100 00100 00000"),
    '.' to g("00000 00000 00000 00000 00000 00000 00100"),
    '-' to g("00000 00000 00000 11111 00000 00000 00000"),
    '/' to g("00001 00001 00010 00100 01000 10000 10000"),
    '%' to g("11001 11010 00010 00100 01000 01011 10011"),
    '→' to g("00000 00100 00010 11111 00010 00100 00000")
)

/**
 * Текст точечной матрицей — фирменный «Nothing»-шрифт, нарисованный на Canvas
 * (никаких файлов шрифтов, ноль нагрузки на память). Только латиница и цифры.
 */
@Composable
fun DotText(
    text: String,
    modifier: Modifier = Modifier,
    maxPitch: Dp = 8.dp,
    color: Color = MaterialTheme.colorScheme.onSurface,
    showOff: Boolean = true
) {
    val s = text.uppercase()
    if (s.isEmpty()) return
    val cols = s.length * 6 - 1
    BoxWithConstraints(modifier) {
        val pitch = minOf(maxPitch, maxWidth / cols)
        val off = color.copy(alpha = 0.13f)
        Canvas(Modifier.size(pitch * cols, pitch * 7)) {
            val p = size.height / 7f
            val r = p * 0.36f
            s.forEachIndexed { ci, ch ->
                val rows = GLYPHS[ch] ?: BLANK
                for (y in 0 until 7) {
                    val row = rows[y]
                    for (x in 0 until 5) {
                        val on = row[x] == '1'
                        if (on || showOff) {
                            drawCircle(if (on) color else off, r, Offset((ci * 6 + x + 0.5f) * p, (y + 0.5f) * p))
                        }
                    }
                }
            }
        }
    }
}

/** Круглая «матрица» с бегущей от красной точки волной. Анимация читается только в фазе рисования. */
@Composable
fun DotOrb(modifier: Modifier = Modifier, n: Int = 17) {
    val fg = MaterialTheme.colorScheme.onSurface
    val inf = rememberInfiniteTransition(label = "orb")
    val t by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2800, easing = LinearEasing)), label = "t")
    Canvas(modifier) {
        val p = size.width / n
        val c = (n - 1) / 2f
        for (i in 0 until n) {
            for (j in 0 until n) {
                val d = hypot(i - c, j - c)
                if (d > c + 0.25f) continue
                val ph = t - d / c
                val f = ph - floor(ph)
                val a = 0.10f + 0.90f * (1f - f).pow(3f)
                val center = Offset((i + 0.5f) * p, (j + 0.5f) * p)
                if (i == n / 2 && j == n / 2) drawCircle(NRed, p * 0.34f, center)
                else drawCircle(fg.copy(alpha = a), p * 0.30f, center)
            }
        }
    }
}

/** Полоса прогресса из точек: заполненные — белые, следующая — пульсирующая красная. */
@Composable
fun DotBar(progress: Float, running: Boolean, modifier: Modifier = Modifier, count: Int = 32) {
    val fg = MaterialTheme.colorScheme.onSurface
    val off = fg.copy(alpha = 0.13f)
    val p by animateFloatAsState(progress, tween(600), label = "bar")
    val inf = rememberInfiniteTransition(label = "barPulse")
    val pulse by inf.animateFloat(0.25f, 1f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "pp")
    Canvas(modifier.fillMaxWidth().height(12.dp)) {
        val pitch = size.width / count
        val r = minOf(pitch * 0.32f, size.height / 2f)
        val lit = floor(p * count).toInt()
        for (i in 0 until count) {
            val col = when {
                i < lit -> fg
                i == lit && running -> NRed.copy(alpha = pulse)
                else -> off
            }
            drawCircle(col, r, Offset((i + 0.5f) * pitch, size.height / 2f))
        }
    }
}

// ───────────────────────── Мелкие элементы ─────────────────────────

/** Моноширинная подпись капсом — «служебный» шрифт Nothing OS. */
@Composable
fun Mono(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = MaterialTheme.colorScheme.onSurfaceVariant,
    size: TextUnit = 12.sp,
    bold: Boolean = false,
    align: TextAlign? = null
) {
    Text(
        text.uppercase(), modifier, color = color, fontFamily = FontFamily.Monospace,
        fontSize = size, letterSpacing = 1.sp, lineHeight = size * 1.4f,
        fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal, textAlign = align
    )
}

@Composable
fun NCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(32.dp),
    content: @Composable () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    Surface(
        modifier, shape = shape, color = cs.surfaceContainerHigh, contentColor = cs.onSurface,
        border = BorderStroke(1.dp, cs.outlineVariant), content = content
    )
}

/** Кнопка-«таблетка»: primary — белая (в тёмной теме), остальные — с тонкой рамкой. */
@Composable
fun NButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    primary: Boolean = false,
    danger: Boolean = false,
    compact: Boolean = false,
    icon: ImageVector? = null
) {
    val cs = MaterialTheme.colorScheme
    val h = if (compact) 44.dp else 56.dp
    val shape = RoundedCornerShape(50)
    val label: @Composable () -> Unit = {
        if (icon != null) {
            Icon(icon, null, Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(
            text.uppercase(), fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold,
            fontSize = 13.sp, letterSpacing = 1.sp, maxLines = 1
        )
    }
    if (primary) {
        Button(
            onClick, modifier.height(h), shape = shape,
            colors = ButtonDefaults.buttonColors(containerColor = cs.primary, contentColor = cs.onPrimary),
            content = { label() }
        )
    } else {
        val tint = if (danger) NRed else cs.onSurface
        OutlinedButton(
            onClick, modifier.height(h), shape = shape,
            border = BorderStroke(1.dp, if (danger) NRed else cs.outline),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = tint),
            content = { label() }
        )
    }
}

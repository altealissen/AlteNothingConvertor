plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.alte.allconvertor"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.alte.allconvertor"; minSdk = 26; targetSdk = 34
        versionCode = 6; versionName = "1.5"
        resourceConfigurations += listOf("en", "ru")
    }
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore"); storePassword = "android"
            keyAlias = "androiddebugkey"; keyPassword = "android"
        }
    }
    buildTypes {
        // Релиз с R8 + ключом debug.keystore: быстрее debug-сборки (нет debuggable-оверхеда, код сжат),
        // подпись та же — обновляется поверх уже установленной версии.
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            signingConfig = signingConfigs.getByName("debug")
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    lint { checkReleaseBuilds = false; abortOnError = false }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")
    implementation("androidx.activity:activity-compose:1.9.0")
    // Применяет baseline-профили Compose при установке — быстрый холодный старт
    implementation("androidx.profileinstaller:profileinstaller:1.3.1")
}

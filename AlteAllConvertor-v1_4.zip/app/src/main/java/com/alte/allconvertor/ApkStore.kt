package com.alte.allconvertor

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import java.io.File

data class SavedApk(val name: String, val uri: Uri, val size: Long, val time: Long)

/**
 * Хранилище собранных APK.
 * Android 10+: публичная папка Download/AlteConvertor (видна в любом файловом менеджере, права не нужны).
 * Android 8–9: папка приложения Android/data/<пакет>/files/apk.
 */
object ApkStore {
    const val DIR = "AlteConvertor"
    private const val MIME = "application/vnd.android.package-archive"

    private fun legacyDir(ctx: Context) = File(ctx.getExternalFilesDir(null), "apk").apply { mkdirs() }

    fun folderLabel(): String =
        if (Build.VERSION.SDK_INT >= 29) "Download/$DIR" else "Android/data/com.alte.allconvertor/files/apk"

    fun save(ctx: Context, src: File, name: String): SavedApk {
        if (Build.VERSION.SDK_INT >= 29) {
            val r = ctx.contentResolver
            val cv = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, MIME)
                put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/$DIR")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = r.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: error("Не удалось создать файл в Download")
            r.openOutputStream(uri)!!.buffered(256 * 1024).use { o -> src.inputStream().use { it.copyTo(o, 256 * 1024) } }
            val done = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
            r.update(uri, done, null, null)
            val len = src.length()
            src.delete()
            return SavedApk(name, uri, len, System.currentTimeMillis())
        }
        val dst = File(legacyDir(ctx), name)
        src.copyTo(dst, overwrite = true)
        src.delete()
        return SavedApk(name, uri(ctx, dst), dst.length(), dst.lastModified())
    }

    private fun size(ctx: Context, uri: Uri): Long =
        ctx.contentResolver.query(uri, arrayOf(MediaStore.MediaColumns.SIZE), null, null, null)
            ?.use { if (it.moveToFirst()) it.getLong(0) else 0L } ?: 0L

    private fun uri(ctx: Context, f: File): Uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)

    fun list(ctx: Context): List<SavedApk> {
        if (Build.VERSION.SDK_INT >= 29) {
            val out = ArrayList<SavedApk>()
            val proj = arrayOf(
                MediaStore.Downloads._ID, MediaStore.Downloads.DISPLAY_NAME,
                MediaStore.Downloads.SIZE, MediaStore.Downloads.DATE_ADDED
            )
            ctx.contentResolver.query(
                MediaStore.Downloads.EXTERNAL_CONTENT_URI, proj,
                "${MediaStore.Downloads.RELATIVE_PATH} LIKE ?",
                arrayOf("${Environment.DIRECTORY_DOWNLOADS}/$DIR/%"),
                "${MediaStore.Downloads.DATE_ADDED} DESC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val n = c.getString(1) ?: continue
                    if (!n.endsWith(".apk")) continue
                    out += SavedApk(
                        n, ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, c.getLong(0)),
                        c.getLong(2), c.getLong(3) * 1000
                    )
                }
            }
            return out
        }
        return legacyDir(ctx).listFiles { f -> f.name.endsWith(".apk") }.orEmpty()
            .sortedByDescending { it.lastModified() }
            .map { SavedApk(it.name, uri(ctx, it), it.length(), it.lastModified()) }
    }

    fun delete(ctx: Context, a: SavedApk): Boolean =
        try {
            if (Build.VERSION.SDK_INT >= 29) ctx.contentResolver.delete(a.uri, null, null) > 0
            else File(legacyDir(ctx), a.name).delete()
        } catch (_: Exception) { false }

    fun install(ctx: Context, a: SavedApk) {
        ctx.startActivity(
            Intent(Intent.ACTION_VIEW).setDataAndType(a.uri, MIME)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}
